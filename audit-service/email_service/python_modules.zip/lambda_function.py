import os
import json
import logging
from smtplib import SMTP
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import boto3

# Configuración del cliente SQS
sqs = boto3.client(
    "sqs",
    region_name=os.getenv("AWS_REGION"),
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
)

# Función para obtener los usuarios de una empresa
def get_users_by_company_id(company_id):
    try:
        response = requests.get(f"{os.getenv('USER_SERVICE_URL')}/{company_id}/users")
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        logging.error(f"Error al obtener usuarios de la empresa: {e}")
        raise ValueError("No se pudieron obtener los usuarios de la empresa.")

# Función para enviar notificaciones por correo electrónico
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os

def send_email_notification(user_email, user_name, feature_name, values):
    try:
        print(f"Enviando correo a {user_email}...")
        # Configuración del correo
        msg = MIMEMultipart()
        msg['From'] = os.getenv("EMAIL_USER")
        msg['To'] = user_email
        msg['Subject'] = f"Notificación de actualización en feature: {feature_name}"

        # Cuerpo del correo
        body = f"""
        Hola {user_name},\n\n
        La feature "{feature_name}" ha sido actualizada.\n
        Detalles: {values}\n
        Te mantenemos informado.\n\n
        Saludos,\n
        Tu equipo.
        """
        msg.attach(MIMEText(body, 'plain'))

        # Conexión al servidor SMTP
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()  # Iniciar cifrado TLS
            server.login(os.getenv("EMAIL_USER"), os.getenv("EMAIL_PASSWORD"))
            server.send_message(msg)

        print(f"Correo enviado a {user_email}")
    except Exception as e:
        print(f"Error al enviar el correo: {e}")


# Función para procesar los mensajes de la cola SQS
def process_sqs_messages():
    try:
        queue_url = os.getenv("SQS_QUEUE_URL")
        print(f"Escuchando mensajes en la cola: {queue_url}")
        while True:  # Mantener el servicio corriendo
            response = sqs.receive_message(
                QueueUrl=queue_url,
                MaxNumberOfMessages=10,  # Procesar hasta 10 mensajes por lote
                WaitTimeSeconds=20       # Long Polling para reducir costos
            )

            if "Messages" in response:
                for message in response["Messages"]:
                    try:
                        # Obtener el cuerpo del mensaje
                        message_body = json.loads(message["Body"])

                        company_id = message_body.get("company_id")
                        feature_name = message_body.get("feature_name")
                        values = message_body.get("values")

                        # Obtener los usuarios de la empresa
                        users = get_users_by_company_id(company_id)

                        for user in users:
                            user_email = user.get("email")
                            user_name = user.get("name")

                            if user_email and user_name:
                                send_email_notification(
                                    user_email, user_name, feature_name, values
                                )

                        # Eliminar mensaje de la cola después de procesarlo
                        receipt_handle = message["ReceiptHandle"]
                        sqs.delete_message(
                            QueueUrl=queue_url,
                            ReceiptHandle=receipt_handle
                        )
                        logging.info(f"Mensaje procesado y eliminado de la cola: {receipt_handle}")
                    except Exception as e:
                        logging.error(f"Error procesando un mensaje: {e}")
                        # No elimines el mensaje de la cola para que pueda reintentar
            else:
                logging.info("No hay mensajes en la cola para procesar.")

    except Exception as e:
        logging.error(f"Error procesando los mensajes de la cola SQS: {e}")
